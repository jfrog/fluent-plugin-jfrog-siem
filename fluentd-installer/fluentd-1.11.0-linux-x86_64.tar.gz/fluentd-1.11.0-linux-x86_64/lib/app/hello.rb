#!/usr/bin/env ruby
require 'concurrent-ruby'
puts "hello world from fluentd"
