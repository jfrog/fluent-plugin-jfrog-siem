class DomainName
  VERSION = '0.5.20190701'
end
