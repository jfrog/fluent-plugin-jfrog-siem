class Strptime
  VERSION = "0.2.4"
end
