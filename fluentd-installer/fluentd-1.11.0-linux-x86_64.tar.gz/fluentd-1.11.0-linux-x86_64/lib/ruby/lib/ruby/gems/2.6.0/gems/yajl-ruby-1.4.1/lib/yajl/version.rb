module Yajl
  VERSION = '1.4.1'
end
