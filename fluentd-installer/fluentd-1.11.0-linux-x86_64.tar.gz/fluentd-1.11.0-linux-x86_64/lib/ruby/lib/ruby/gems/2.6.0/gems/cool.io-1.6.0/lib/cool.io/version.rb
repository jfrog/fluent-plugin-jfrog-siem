module Coolio
  VERSION = "1.6.0"
  
  def self.version
    VERSION
  end
end
