# This file exists for backward compatbility with require 'rest_client'
require File.dirname(__FILE__) + '/restclient'
